# APK Sideloading & Printable PDF MCQ Worksheet Export

Enable direct Android phone installation via AI Studio's APK export workflow and add an offline, zero-permission **PDF MCQ Worksheet Exporter** inside the RRB Nursing CBT app so learners can print or study custom question booklets with optional answer keys and rationales.

### User Review & Critical Decisions

> [!IMPORTANT]
> **Confirmed Phase 1 Decisions**:
> - **App Export Goal**: Export an installable Android **APK** from Google AI Studio to sideload directly onto an Android phone (instructions below, no code changes required for APK generation itself).
> - **In-App Export Format**: Build a native **PDF / Printable MCQ Worksheet Export** alongside the existing JSON backup/restore workflow.
> - **Recommended Defaults**: Use Android's built-in `PdfDocument` engine + Storage Access Framework (`CreateDocument`) so zero extra storage permissions or heavy third-party PDF dependencies are needed, and place export triggers in both the **Import / Export Hub** and the **Revision Deck** screen.

- **AI Studio APK Export Workflow (Ready Now)**:
  1. Open the **Settings / Export menu** in the top-right bar of the AI Studio workspace and select **Generate APK** (or **Download Project ZIP** if building locally in Android Studio).
  2. Transfer the downloaded `.apk` file to your Android phone (USB, Google Drive, or direct mobile download), tap it, and allow **Install unknown apps** if prompted by Android.
  3. *(Note)* No AI Studio branding or platform references will be placed inside the Android app itself.

### 1. Overview & Core Concept

- **What It Does**: Adds an offline **Printable PDF Worksheet Generator** to the RRB Nursing CBT app, letting learners export curated A4 PDF study booklets filtered by source (All, Subject, PYQ Shift, Bookmarks, Recent Mistakes, or Lowest Accuracy) and Difficulty (`All`, `Easy`, `Medium`, `Hard`), with configurable question count, blank exam sheet vs. answer key + clinical rationales, and instant saving to device storage.
- **Target Audience / Persona**: Nursing Superintendent and Staff Nurse exam aspirants who want to print practice papers for offline pen-and-paper drills, revision binders, or sharing study worksheets across devices.
- **Key Value**: Transforms the 601-question offline bank (plus user-imported shift questions) into clean, exam-ready A4 PDF booklets without internet access, storage permissions, or external libraries.

### 2. User Experience & Visual Design

- **Key User Flows**:
  1. **Launch Worksheet Exporter**: From the Dashboard's **Import & Export** card, top bar action, or the **Revision Deck** header (`Export PDF` button), the user opens the **Export PDF Worksheet** modal sheet (or dedicated tab inside the Backup & Export modal).
  2. **Configure Booklet**: Choose Source Scope (Current Filter, Bookmarks, Mistakes, Lowest Accuracy, Subject, or PYQ Shift), Difficulty (`All`, `Easy`, `Medium`, `Hard`), Question Limit (`15`, `30`, `50`, `100`, or `All` matching), and Layout Mode (`Practice Paper + Answer Key at End` or `Study Sheet with Inline Rationales`).
  3. **Live Preview Summary**: Displays matching question count, estimated A4 page count, and active difficulty/category badges before generating.
  4. **Zero-Permission Save**: Tapping **Save PDF Worksheet** opens Android's system document picker (`application/pdf`) with a smart filename (e.g., `rrb-nursing-msn-medium-30q.pdf`), streams the generated PDF in the background with a progress indicator, and shows a confirmation snackbar when complete.
- **Visual Identity & Theme**:
  - *Aesthetic Direction*: Crisp clinical-editorial study utility matching the existing exam simulator.
  - *Color Palette & Mood*: Uses `MaterialTheme.colorScheme` semantic tokens (`CobaltPrimary`, `TealSecondary`, `EmeraldCorrect`, `AmberHighlight`, `RoseWrong`) on `LightSurface`/`DarkSurface` cards. Generated A4 PDF pages use high-contrast ink-friendly monochrome typography (`#0F172A` headings, `#334155` body, `#E2E8F0` dividers) so printed pages stay sharp and economical on black-and-white printers.
  - *Typography & Hierarchy*: In-app UI uses `Plus Jakarta Sans` (`DisplayFontFamily`) for headers, `Inter` (`BodyFontFamily`) for controls, and `JetBrains Mono` (`MonoFontFamily`) for counts/badges. PDF pages render clean multi-line wrapped stems, `A/B/C/D` option columns, page numbers, and a structured answer-key grid.
  - *Component Styling & Layout*: Material 3 `ModalBottomSheet` with `FilterChip` selectors, `RoundedCornerShape(12.dp–18.dp)` surfaces, 48dp minimum touch targets, and `testTag` identifiers on all interactive controls.
- **Interactive Feedback & Motion**: Smooth `AnimatedVisibility` transitions when toggling worksheet options, inline loading spinner while rendering multi-page PDFs on `Dispatchers.IO`, and `SnackbarHost` confirmation or error recovery messages.

### 3. Key Product Decisions & Trade-Offs

- **Decision 1: PDF Rendering Engine**
  - *Chosen Approach*: Native Android `android.graphics.pdf.PdfDocument` with `TextPaint` / `StaticLayout` pagination on `Dispatchers.IO`.
  - *Why*: Zero APK bloat, completely offline, no native C++ library conflicts across ABIs, and exact control over A4 page margins, multi-line option wrapping, and answer-key tables.
  - *Alternatives Considered*: Third-party PDF libraries (iText / PdfBox-Android) add megabytes to APK size and licensing/reflection overhead.
- **Decision 2: File Saving & Google Play Compliance**
  - *Chosen Approach*: Storage Access Framework via `ActivityResultContracts.CreateDocument("application/pdf")`.
  - *Why*: Requires zero storage permissions, respects scoped storage on all modern Android versions, and lets users save straight to Downloads, SD card, or Drive.
  - *Alternatives Considered*: Writing directly to `Downloads` via legacy permissions or `MediaStore` — unnecessary complexity and permission prompts.
- **Decision 3: Layout Modes**
  - *Chosen Approach*: Two clear modes: **Mock Test Booklet** (clean questions + separate Answer Key & Rationale pages at the back) and **Rapid Revision Sheet** (questions with highlighted correct answers and rationales inline).
  - *Why*: Supports both timed pen-and-paper self-testing and passive reading/printouts.
  - *Alternatives Considered*: Single fixed layout — forces users into either spoiling answers or losing explanations.

### 4. Technical Architecture & Data Strategy

- **Architecture & Component Diagram**:

```text
┌─────────────────────────────────────────────────────────────────────────┐
│                           Compose UI Layer                              │
│  ┌──────────────────────┐   ┌───────────────────────┐                   │
│  │  Dashboard & Deck    │──▶│ Export Worksheet Modal │                   │
│  │  (Entry Triggers)    │   │ (Scope, Diff, Mode)   │                   │
│  └──────────────────────┘   └──────────┬────────────┘                   │
│                                        │ launches CreateDocument(pdf)   │
│                                        ▼                                │
│                           ┌─────────────────────────┐                   │
│                           │  System Document Picker │                   │
│                           └────────────┬────────────┘                   │
└────────────────────────────────────────┼────────────────────────────────┘
                                         │ OutputStream URI
                                         ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                       ViewModel & PDF Engine                            │
│  ┌──────────────────────┐   ┌───────────────────────┐                   │
│  │    MainViewModel     │──▶│   PdfWorksheetWriter  │                   │
│  │  (Filter & Export    │   │  (PdfDocument + A4    │                   │
│  │   StateFlow)         │   │   StaticLayout Pager) │                   │
│  └──────────┬───────────┘   └───────────────────────┘                   │
│             │ reads filtered QuestionItems                              │
│             ▼                                                           │
│  ┌───────────────────────────────────────────────────────────────────┐  │
│  │             NursingPrepRepository & Room Database                 │  │
│  │   (601+ Built-in MCQs, Custom Imports, Bookmarks, Attempt Stats)  │  │
│  └───────────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────┘
```

- **Data Model & State**:
  - `PdfExportConfig`: Holds selected `sourceKey` (All, Bookmarks, Mistakes, Lowest Accuracy, Subject, or PYQ Shift), `DifficultyFilter` (`ALL`, `EASY`, `MEDIUM`, `HARD`), `maxQuestions` (`Int?`), `includeAnswerKey` (`Boolean`), `inlineAnswers` (`Boolean`), and `isExporting` (`Boolean`).
  - Derived preview list reuses `MainViewModel`'s filtering pipeline so question counts and ordering match practice/revision modes identically.
- **Interactive Component & State Mapping**:
  - Selecting source, difficulty, count, or layout chips updates `PdfExportConfig` state and recomputes matching count and suggested filename reactively.
  - Clicking **Save PDF Worksheet** launches `CreateDocument("application/pdf")`; once a `Uri` is returned, `MainViewModel` invokes `PdfWorksheetWriter` on `Dispatchers.IO` to paginate `StaticLayout` text blocks cleanly across A4 pages (`595 x 842 pt`), writes to `ContentResolver.openOutputStream(uri)`, clears loading state, and emits a success/failure snackbar.
  - Existing **JSON Backup Export** and **Restore File** controls remain intact for full app-data portability.
